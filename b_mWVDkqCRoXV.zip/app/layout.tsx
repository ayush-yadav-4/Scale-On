import type { Metadata, Viewport } from 'next'
import { Analytics } from '@vercel/analytics/next'
import ThemeProvider from '@/components/providers/ThemeProvider'
import './globals.css'

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#ffffff',
}

export const metadata: Metadata = {
  title: 'ScaleOn — IT Agency for Web Development, Cloud & AI Solutions',
  description: 'ScaleOn is a modern IT agency offering full stack web development, cloud solutions, AI agents, and custom websites. Build faster. Scale smarter.',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'ScaleOn — IT Agency for Web Development, Cloud & AI Solutions',
    description: 'ScaleOn is a modern IT agency offering full stack web development, cloud solutions, AI agents, and custom websites.',
    url: 'https://scaleon.io',
    siteName: 'ScaleOn',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning data-scroll-behavior="smooth">
      <body className="font-sans antialiased bg-white dark:bg-slate-950 text-slate-950 dark:text-slate-50 transition-colors duration-300 overflow-x-hidden">
        <ThemeProvider>
          {children}
        </ThemeProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
