'use client'

import React from 'react'
import { cn } from '@/lib/utils'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  isLoading?: boolean
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ 
    className, 
    variant = 'primary', 
    size = 'md', 
    isLoading = false,
    disabled,
    children,
    ...props 
  }, ref) => {
    const baseStyles = 'relative font-body font-medium transition-all duration-300 cursor-pointer rounded-lg overflow-hidden group'
    
    const variants = {
      primary: `bg-gradient-to-r from-emerald-500 to-teal-500 dark:from-emerald-600 dark:to-teal-600 text-white hover:scale-105 hover:shadow-lg hover:[box-shadow:0_0_20px_rgba(16,185,129,0.4)] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100`,
      secondary: `bg-white/10 dark:bg-white/5 border border-white/30 dark:border-white/20 text-white hover:bg-white/20 dark:hover:bg-white/10 hover:border-white/50 dark:hover:border-white/30 disabled:opacity-50 disabled:cursor-not-allowed`,
      ghost: `bg-transparent text-slate-700 dark:text-white hover:text-emerald-600 dark:hover:text-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed`
    }

    const sizes = {
      sm: 'px-4 py-2 text-sm',
      md: 'px-8 py-3 text-base',
      lg: 'px-12 py-4 text-lg'
    }

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        {...props}
      >
        {/* Shimmer effect for primary button */}
        {variant === 'primary' && (
          <div className="absolute inset-0 overflow-hidden rounded-lg">
            <div 
              className="absolute inset-0 w-full h-full bg-white/20 animate-shimmer"
              style={{
                animation: 'shimmer 0.6s ease-in-out',
                animationDelay: '0s'
              }}
            />
          </div>
        )}
        
        <span className="relative flex items-center justify-center gap-2">
          {isLoading && (
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
          )}
          {children}
        </span>
      </button>
    )
  }
)

Button.displayName = 'Button'
