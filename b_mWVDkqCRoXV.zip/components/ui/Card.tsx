'use client'

import React from 'react'
import { cn } from '@/lib/utils'

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'glass' | 'gradient'
  hoverable?: boolean
}

export const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, variant = 'default', hoverable = false, ...props }, ref) => {
    const variants = {
      default: `bg-[#0a1628] border border-[rgba(0,200,255,0.08)] ${
        hoverable 
          ? 'transition-all duration-400 hover:border-[rgba(0,200,255,0.25)] hover:bg-[#0f1f38] hover:-translate-y-1 hover:shadow-[0_0_40px_rgba(0,200,255,0.15)]' 
          : ''
      }`,
      glass: 'glass-effect bg-[rgba(15,31,56,0.6)] backdrop-blur-xl border border-[rgba(0,200,255,0.1)]',
      gradient: `bg-gradient-card border border-[rgba(0,200,255,0.08)] ${
        hoverable 
          ? 'transition-all duration-400 hover:border-[rgba(0,200,255,0.25)] hover:-translate-y-1 hover:shadow-[0_0_60px_rgba(0,102,255,0.2)]' 
          : ''
      }`
    }

    return (
      <div
        ref={ref}
        className={cn(
          'rounded-2xl p-8 transition-all',
          variants[variant],
          className
        )}
        {...props}
      />
    )
  }
)

Card.displayName = 'Card'

export const CardHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('flex flex-col space-y-1.5 mb-4', className)}
    {...props}
  />
))
CardHeader.displayName = 'CardHeader'

export const CardTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h3
    ref={ref}
    className={cn('text-2xl font-display font-bold text-[#e8f0fe]', className)}
    {...props}
  />
))
CardTitle.displayName = 'CardTitle'

export const CardDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    className={cn('text-sm text-[#7a9cc0]', className)}
    {...props}
  />
))
CardDescription.displayName = 'CardDescription'

export const CardContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn('', className)} {...props} />
))
CardContent.displayName = 'CardContent'

export const CardFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('flex items-center pt-6 gap-4', className)}
    {...props}
  />
))
CardFooter.displayName = 'CardFooter'
