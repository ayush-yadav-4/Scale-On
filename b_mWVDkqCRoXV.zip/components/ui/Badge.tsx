'use client'

import React from 'react'
import { cn } from '@/lib/utils'

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'success'
  icon?: React.ReactNode
}

export const Badge = React.forwardRef<HTMLDivElement, BadgeProps>(
  ({ className, variant = 'default', icon, children, ...props }, ref) => {
    const variants = {
      default: 'bg-[rgba(0,200,255,0.15)] border border-[rgba(0,200,255,0.25)] text-[#00c8ff]',
      success: 'bg-[rgba(0,229,160,0.15)] border border-[rgba(0,229,160,0.25)] text-[#00e5a0]'
    }

    return (
      <div
        ref={ref}
        className={cn(
          'inline-flex items-center gap-2 px-4 py-2 rounded-full font-mono-custom text-sm font-medium',
          variants[variant],
          className
        )}
        {...props}
      >
        {icon && <span className="w-4 h-4">{icon}</span>}
        {children}
      </div>
    )
  }
)

Badge.displayName = 'Badge'
